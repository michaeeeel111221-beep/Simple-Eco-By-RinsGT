package com.rinsgt.simpleeconomyshop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

/** Saldo disimpan per-world di file simple_economy_shop.json di folder world. */
final class Economy {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Long> BAL = new HashMap<>();
    private static Path file;

    static void load(MinecraftServer server) {
        BAL.clear();
        file = server.getWorldPath(LevelResource.ROOT).resolve("simple_economy_shop.json");
        try {
            if (Files.exists(file)) {
                Map<String, Long> m = GSON.fromJson(Files.readString(file), new TypeToken<Map<String, Long>>() {}.getType());
                if (m != null) BAL.putAll(m);
            }
        } catch (Exception e) {
            System.err.println("[SimpleEconomyShop] Gagal membaca saldo: " + e);
        }
    }

    static void save() {
        if (file == null) return;
        try {
            Files.writeString(file, GSON.toJson(BAL));
        } catch (Exception e) {
            System.err.println("[SimpleEconomyShop] Gagal menyimpan saldo: " + e);
        }
    }

    static long get(UUID id) { return BAL.getOrDefault(id.toString(), 0L); }

    static void add(UUID id, long amount) {
        BAL.put(id.toString(), get(id) + amount);
        save();
    }

    static boolean take(UUID id, long amount) {
        if (get(id) < amount) return false;
        BAL.put(id.toString(), get(id) - amount);
        save();
        return true;
    }
}

package com.rinsgt.simpleeconomyshop;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class ShopMenu extends ChestMenu {
    private static final int PER_PAGE = 40;
    private static final int MAX_QTY = 2304;

    private final SimpleContainer box;
    private final ServerPlayer player;
    private final List<Catalog.Entry> list;
    private int page = 0;
    private int selected = -1;
    private int qty = 1;

    public ShopMenu(int id, Inventory inv, ServerPlayer player) {
        this(id, inv, player, new SimpleContainer(54));
    }

    private ShopMenu(int id, Inventory inv, ServerPlayer player, SimpleContainer box) {
        super(MenuType.GENERIC_9x6, id, inv, box, 6);
        this.box = box;
        this.player = player;
        this.list = Catalog.get(player.level().getServer());
        refresh();
    }

    private int pages() { return Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE); }

    private void refresh() {
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 8; c++) {
                int idx = page * PER_PAGE + r * 8 + c;
                ItemStack out = ItemStack.EMPTY;
                if (idx < list.size()) {
                    Catalog.Entry e = list.get(idx);
                    out = e.stack().copy();
                    Gui.lore(out, "Harga beli: " + Gui.money(e.buy()) + " / item", "Klik untuk memilih");
                    if (idx == selected) out.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
                }
                box.setItem(r * 9 + c, out);
            }
        }
        box.setItem(45, Gui.icon(Items.ARROW, Gui.text("< Halaman sebelumnya", ChatFormatting.YELLOW), "Klik: -1 halaman", "Shift+klik: -5 halaman"));
        box.setItem(46, Gui.icon(Items.ARROW, Gui.text("Halaman berikutnya >", ChatFormatting.YELLOW), "Klik: +1 halaman", "Shift+klik: +5 halaman"));
        box.setItem(47, Gui.icon(Items.RED_STAINED_GLASS_PANE, Gui.text("- Kurangi jumlah", ChatFormatting.RED), "Klik kiri: -1", "Klik kanan: -16", "Shift+klik: -64"));
        box.setItem(49, Gui.icon(Items.LIME_STAINED_GLASS_PANE, Gui.text("+ Tambah jumlah", ChatFormatting.GREEN), "Klik kiri: +1", "Klik kanan: +16", "Shift+klik: +64"));
        box.setItem(51, Gui.icon(Items.RED_CONCRETE, Gui.text("BATAL / PILIH ULANG", ChatFormatting.RED)));
        box.setItem(52, Gui.icon(Items.PAPER, Gui.text("Halaman " + (page + 1) + " / " + pages(), ChatFormatting.WHITE)));
        if (selected < 0 || selected >= list.size()) {
            box.setItem(48, Gui.icon(Items.PAPER, Gui.text("Pilih item dulu", ChatFormatting.GRAY)));
            box.setItem(50, Gui.icon(Items.GRAY_CONCRETE, Gui.text("KONFIRMASI BELI", ChatFormatting.GRAY), "Belum ada item dipilih"));
        } else {
            Catalog.Entry e = list.get(selected);
            long total = e.buy() * qty;
            ItemStack sel = e.stack().copy();
            sel.setCount(Math.min(qty, sel.getMaxStackSize()));
            Gui.lore(sel, "Jumlah: " + qty, "Harga: " + Gui.money(e.buy()) + " x " + qty, "Total: " + Gui.money(total));
            box.setItem(48, sel);
            box.setItem(50, Gui.icon(Items.LIME_CONCRETE, Gui.text("KONFIRMASI BELI", ChatFormatting.GREEN),
                "Beli " + qty + " item", "Total: " + Gui.money(total), "Saldo: " + Gui.money(Economy.get(player.getUUID()))));
        }
        box.setItem(53 - 0, Gui.icon(Items.BARRIER, Gui.text("Tutup", ChatFormatting.RED)));
        Gui.panel(box, player);
    }

    private void msg(String s, ChatFormatting f) { player.sendSystemMessage(Gui.text(s, f)); }

    private void confirm() {
        if (selected < 0 || selected >= list.size()) { msg("Pilih item dulu.", ChatFormatting.RED); return; }
        Catalog.Entry e = list.get(selected);
        long total = e.buy() * qty;
        if (Economy.get(player.getUUID()) < total) { msg("Uang tidak cukup. Butuh " + Gui.money(total) + ".", ChatFormatting.RED); return; }
        Inventory inv = player.getInventory();
        long room = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) room += e.stack().getMaxStackSize();
            else if (ItemStack.isSameItemSameComponents(s, e.stack())) room += s.getMaxStackSize() - s.getCount();
        }
        if (room < qty) { msg("Inventory tidak cukup untuk " + qty + " item.", ChatFormatting.RED); return; }
        if (!Economy.take(player.getUUID(), total)) return;
        int left = qty;
        while (left > 0) {
            int n = Math.min(left, e.stack().getMaxStackSize());
            ItemStack give = e.stack().copyWithCount(n);
            inv.add(give);
            if (!give.isEmpty()) player.drop(give, false);
            left -= n;
        }
        msg("Berhasil beli " + qty + "x " + e.stack().getHoverName().getString() + " seharga " + Gui.money(total) + ".", ChatFormatting.GREEN);
    }

    @Override
    public void clicked(int slotId, int button, ClickType type, Player p) {
        if (slotId >= 0 && slotId < 54 && (type == ClickType.PICKUP || type == ClickType.QUICK_MOVE)) {
            boolean shift = type == ClickType.QUICK_MOVE;
            int step = shift ? 64 : (button == 1 ? 16 : 1);
            int row = slotId / 9, col = slotId % 9;
            if (col < 8 && row < 5) {
                int idx = page * PER_PAGE + row * 8 + col;
                if (idx < list.size()) { selected = idx; qty = 1; }
            } else {
                switch (slotId) {
                    case 45 -> page = Math.max(0, page - (shift ? 5 : 1));
                    case 46 -> page = Math.min(pages() - 1, page + (shift ? 5 : 1));
                    case 47 -> qty = Math.max(1, qty - step);
                    case 49 -> qty = Math.min(MAX_QTY, qty + step);
                    case 50 -> confirm();
                    case 51 -> { selected = -1; qty = 1; }
                    case 53 -> { player.closeContainer(); return; }
                    default -> { }
                }
            }
            refresh();
        }
        setCarried(ItemStack.EMPTY);
        sendAllDataToRemote();
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) { return ItemStack.EMPTY; }
}

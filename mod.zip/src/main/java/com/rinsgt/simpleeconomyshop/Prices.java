package com.rinsgt.simpleeconomyshop;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/** Harga jual (sell) per item. Harga beli = setengah harga jual (min 1). */
final class Prices {
    private static final Map<String, Long> X = new HashMap<>();

    private static void p(String id, long v) { X.put(id, v); }

    static {
        // bahan tambang
        p("coal", 12); p("charcoal", 10); p("raw_iron", 60); p("iron_ingot", 70); p("iron_nugget", 8);
        p("raw_copper", 25); p("copper_ingot", 40); p("raw_gold", 90); p("gold_ingot", 100); p("gold_nugget", 11);
        p("diamond", 600); p("emerald", 300); p("lapis_lazuli", 25); p("redstone", 20); p("quartz", 40);
        p("amethyst_shard", 30); p("netherite_scrap", 1000); p("netherite_ingot", 4000); p("ancient_debris", 1200);
        p("coal_ore", 12); p("iron_ore", 60); p("copper_ore", 25); p("gold_ore", 90); p("diamond_ore", 600);
        p("emerald_ore", 300); p("lapis_ore", 150); p("redstone_ore", 100); p("nether_gold_ore", 45); p("nether_quartz_ore", 40);
        p("coal_block", 108); p("iron_block", 630); p("copper_block", 360); p("gold_block", 900); p("diamond_block", 5400);
        p("emerald_block", 2700); p("lapis_block", 225); p("redstone_block", 180); p("netherite_block", 36000);
        p("raw_iron_block", 540); p("raw_copper_block", 225); p("raw_gold_block", 810); p("quartz_block", 160); p("amethyst_block", 120);
        // drop mob & langka
        p("rotten_flesh", 3); p("bone", 6); p("bone_meal", 2); p("bone_block", 18); p("string", 6); p("spider_eye", 8);
        p("gunpowder", 25); p("ender_pearl", 100); p("ender_eye", 120); p("blaze_rod", 80); p("blaze_powder", 40);
        p("ghast_tear", 200); p("slime_ball", 25); p("magma_cream", 50); p("nether_star", 8000);
        p("wither_skeleton_skull", 3000); p("shulker_shell", 500); p("dragon_egg", 50000); p("elytra", 8000);
        p("totem_of_undying", 5000); p("beacon", 12000); p("trident", 4000); p("heart_of_the_sea", 3000);
        p("nautilus_shell", 500); p("golden_apple", 400); p("enchanted_golden_apple", 4000); p("experience_bottle", 60);
        p("name_tag", 100); p("saddle", 150); p("echo_shard", 300); p("sponge", 100); p("wet_sponge", 80); p("tnt", 60);
        p("glowstone_dust", 15); p("glowstone", 60); p("obsidian", 40); p("crying_obsidian", 80); p("prismarine_shard", 20);
        p("prismarine_crystals", 25); p("leather", 10); p("feather", 4); p("ink_sac", 8); p("glow_ink_sac", 20);
        p("honeycomb", 20); p("honey_bottle", 30); p("egg", 3); p("nether_wart", 12); p("chorus_fruit", 10);
        // tanaman & dasar
        p("wheat", 4); p("carrot", 4); p("potato", 4); p("beetroot", 4); p("sugar_cane", 4); p("sugar", 5); p("pumpkin", 8);
        p("melon_slice", 2); p("cocoa_beans", 6); p("kelp", 2); p("bamboo", 2); p("cactus", 3); p("wheat_seeds", 1);
        p("sweet_berries", 3); p("stick", 1); p("cobblestone", 2); p("stone", 3); p("dirt", 1); p("sand", 2); p("gravel", 2);
        p("clay_ball", 3); p("brick", 5); p("flint", 3); p("netherrack", 1); p("end_stone", 5); p("deepslate", 3);
    }

    static boolean excluded(String p) {
        if (p.equals("air") || p.equals("bedrock") || p.equals("barrier") || p.equals("light") || p.equals("spawner")
            || p.equals("farmland") || p.equals("dirt_path") || p.equals("end_portal_frame") || p.equals("reinforced_deepslate")
            || p.equals("budding_amethyst") || p.equals("chorus_plant") || p.equals("frogspawn") || p.equals("petrified_oak_slab")
            || p.equals("jigsaw") || p.equals("debug_stick") || p.equals("knowledge_book") || p.equals("player_head")
            || p.equals("written_book") || p.equals("filled_map") || p.equals("enchanted_book") || p.equals("vault")
            || p.equals("trial_spawner") || p.equals("structure_void") || p.equals("structure_block")) return true;
        return p.contains("command_block") || p.contains("spawn_egg") || p.contains("infested_") || p.contains("test_")
            || p.contains("suspicious_") || p.equals("potion") || p.equals("splash_potion") || p.equals("lingering_potion")
            || p.equals("tipped_arrow");
    }

    private static final String[] MATS = {"wooden", "stone", "leather", "chainmail", "copper", "iron", "golden", "diamond", "netherite"};
    private static final long[] MV = {2, 2, 5, 20, 40, 70, 100, 600, 1500};
    private static final String[] PARTS = {"sword", "pickaxe", "axe", "shovel", "hoe", "helmet", "chestplate", "leggings", "boots", "spear"};
    private static final long[] PC = {2, 3, 3, 1, 2, 5, 8, 7, 4, 2};

    static long base(Item item, String p) {
        Long e = X.get(p);
        if (e != null) return e;
        if (p.startsWith("deepslate_") && X.containsKey(p.substring(10))) return X.get(p.substring(10));
        for (int i = 0; i < MATS.length; i++)
            for (int j = 0; j < PARTS.length; j++)
                if (p.equals(MATS[i] + "_" + PARTS[j])) return MV[i] * PC[j];
        if (p.equals("turtle_helmet")) return 300;
        if (p.endsWith("_horse_armor")) return 150;
        if (p.endsWith("_log") || p.endsWith("_wood") || p.endsWith("_stem") || p.endsWith("_hyphae")) return 10;
        if (p.endsWith("_planks")) return 3;
        if (p.endsWith("_stairs") || p.endsWith("_slab") || p.endsWith("_fence") || p.endsWith("_fence_gate")
            || p.endsWith("_door") || p.endsWith("_trapdoor") || p.endsWith("_button") || p.endsWith("_pressure_plate")
            || p.endsWith("_sign") || p.endsWith("_wall")) return 4;
        if (p.endsWith("_wool") || p.endsWith("_carpet") || p.endsWith("_bed") || p.endsWith("_banner")) return 8;
        if (p.endsWith("concrete") || p.endsWith("concrete_powder") || p.endsWith("terracotta") || p.endsWith("stained_glass")
            || p.endsWith("stained_glass_pane") || p.endsWith("_candle")) return 6;
        if (p.endsWith("_shulker_box") || p.equals("shulker_box")) return 600;
        if (p.startsWith("music_disc_")) return 400;
        if (p.endsWith("_pottery_sherd") || p.endsWith("_armor_trim_smithing_template") || p.endsWith("_upgrade_smithing_template")) return 250;
        if (p.endsWith("_dye")) return 5;
        if (p.endsWith("_sapling")) return 6;
        if (p.endsWith("_leaves")) return 3;
        if (p.endsWith("_boat") || p.endsWith("_chest_boat") || p.endsWith("_raft") || p.endsWith("_chest_raft")) return 15;
        if (item.components().has(DataComponents.FOOD)) return 12;
        return 8;
    }

    /** Harga jual 1 buah item; 0 jika tidak bisa dijual. */
    static long sell(ItemStack st) {
        if (st.isEmpty()) return 0;
        Item item = st.getItem();
        String p = BuiltInRegistries.ITEM.getKey(item).getPath();
        if (excluded(p)) return 0;
        if (item == Items.ENCHANTED_BOOK) {
            ItemEnchantments en = st.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY);
            int sum = 0;
            for (var entry : en.entrySet()) sum += entry.getIntValue();
            return sum <= 0 ? 0 : 150L * sum;
        }
        // jangan hapus isi shulker box / bundle
        ItemContainerContents c = st.get(DataComponents.CONTAINER);
        if (c != null && c.nonEmptyItems().iterator().hasNext()) return 0;
        var b = st.get(DataComponents.BUNDLE_CONTENTS);
        if (b != null && !b.isEmpty()) return 0;
        return base(item, p);
    }

    static long buyFromSell(long sell) { return Math.max(1, Math.round(sell * 0.5)); }
}

package com.rinsgt.simpleeconomyshop;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

final class Gui {
    static MutableComponent text(String s, ChatFormatting... f) {
        return Component.literal(s).withStyle(Style.EMPTY.withItalic(false)).withStyle(f);
    }

    static void lore(ItemStack st, String... lines) {
        List<Component> l = new ArrayList<>();
        for (String s : lines) l.add(text(s, ChatFormatting.GRAY));
        st.set(DataComponents.LORE, new ItemLore(l));
    }

    static ItemStack icon(Item item, Component name, String... lore) {
        ItemStack st = new ItemStack(item);
        st.set(DataComponents.CUSTOM_NAME, name);
        if (lore.length > 0) lore(st, lore);
        return st;
    }

    static ItemStack filler() {
        return icon(Items.GRAY_STAINED_GLASS_PANE, text(" "));
    }

    static String money(long n) { return String.format(Locale.US, "$%,d", n); }

    /** Panel info di kolom paling kanan GUI. */
    static void panel(Container box, ServerPlayer p) {
        box.setItem(8, icon(Items.NETHER_STAR, text("SURVIVAL HARDCORE", ChatFormatting.GOLD, ChatFormatting.BOLD)));
        box.setItem(17, icon(Items.GOLD_INGOT, text("Money: " + money(Economy.get(p.getUUID())), ChatFormatting.GREEN)));
        box.setItem(26, icon(Items.NAME_TAG, text("IGN: " + p.getName().getString(), ChatFormatting.AQUA)));
        box.setItem(35, icon(Items.ENDER_EYE, text("LIVE: TikTok @rinsgt", ChatFormatting.RED)));
        box.setItem(44, filler());
        box.setItem(53, icon(Items.BARRIER, text("Tutup", ChatFormatting.RED)));
    }
}

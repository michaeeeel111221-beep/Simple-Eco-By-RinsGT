package com.rinsgt.simpleeconomyshop;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class SellMenu extends ChestMenu {
    private final SimpleContainer box;
    private final ServerPlayer player;

    public SellMenu(int id, Inventory inv, ServerPlayer player) {
        this(id, inv, player, new SimpleContainer(54));
    }

    private SellMenu(int id, Inventory inv, ServerPlayer player, SimpleContainer box) {
        super(MenuType.GENERIC_9x6, id, inv, box, 6);
        this.box = box;
        this.player = player;
        for (int i = 45; i < 53; i++) box.setItem(i, Gui.filler());
        update();
    }

    private static boolean isDeposit(int s) { return s >= 0 && s < 45 && s % 9 < 8; }

    private long total() {
        long t = 0;
        for (int i = 0; i < 45; i++) {
            if (!isDeposit(i)) continue;
            ItemStack s = box.getItem(i);
            t += Prices.sell(s) * s.getCount();
        }
        return t;
    }

    private void update() {
        long t = total();
        box.setItem(49, Gui.icon(Items.LIME_CONCRETE, Gui.text("JUAL SEMUA", ChatFormatting.GREEN),
            "Total: " + Gui.money(t), "Taruh item di slot kosong", "(shift+klik dari inventory)", "Item tak bisa dijual tetap kembali"));
        Gui.panel(box, player);
    }

    private void sell() {
        long t = 0;
        int count = 0;
        for (int i = 0; i < 45; i++) {
            if (!isDeposit(i)) continue;
            ItemStack s = box.getItem(i);
            long price = Prices.sell(s);
            if (price > 0) {
                t += price * s.getCount();
                count += s.getCount();
                box.setItem(i, ItemStack.EMPTY);
            }
        }
        if (t <= 0) { player.sendSystemMessage(Gui.text("Tidak ada item yang bisa dijual.", ChatFormatting.RED)); return; }
        Economy.add(player.getUUID(), t);
        player.sendSystemMessage(Gui.text("Berhasil jual " + count + " item seharga " + Gui.money(t) + ".", ChatFormatting.GREEN));
    }

    @Override
    public void clicked(int slotId, int button, ClickType type, Player p) {
        if (type == ClickType.QUICK_CRAFT || type == ClickType.PICKUP_ALL) { sendAllDataToRemote(); return; }
        if (slotId >= 0 && slotId < 54 && !isDeposit(slotId)) {
            if (type == ClickType.PICKUP || type == ClickType.QUICK_MOVE) {
                if (slotId == 49) sell();
                else if (slotId == 53) { player.closeContainer(); return; }
            }
            update();
            sendAllDataToRemote();
            return;
        }
        super.clicked(slotId, button, type, p);
        update();
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack orig = slot.getItem();
        ItemStack copy = orig.copy();
        boolean moved = false;
        if (index < 54) {
            int before = orig.getCount();
            if (!this.moveItemStackTo(orig, 54, this.slots.size(), true)) return ItemStack.EMPTY;
            moved = orig.getCount() != before;
        } else {
            int before = orig.getCount();
            for (int pass = 0; pass < 2 && !orig.isEmpty(); pass++) {
                for (int i = 0; i < 45 && !orig.isEmpty(); i++) {
                    if (!isDeposit(i)) continue;
                    Slot d = this.slots.get(i);
                    ItemStack cur = d.getItem();
                    if (pass == 0 && !cur.isEmpty() && ItemStack.isSameItemSameComponents(cur, orig)) {
                        int m = Math.min(orig.getCount(), d.getMaxStackSize(cur) - cur.getCount());
                        if (m > 0) { cur.grow(m); orig.shrink(m); d.setChanged(); }
                    } else if (pass == 1 && cur.isEmpty()) {
                        int m = Math.min(orig.getCount(), d.getMaxStackSize(orig));
                        d.set(orig.copyWithCount(m));
                        orig.shrink(m);
                    }
                }
            }
            moved = orig.getCount() != before;
        }
        if (orig.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        return moved ? copy : ItemStack.EMPTY;
    }

    @Override
    public void removed(Player p) {
        for (int i = 0; i < 45; i++) {
            if (!isDeposit(i)) continue;
            ItemStack s = box.removeItemNoUpdate(i);
            if (!s.isEmpty()) p.getInventory().placeItemBackInInventory(s);
        }
        super.removed(p);
    }
}

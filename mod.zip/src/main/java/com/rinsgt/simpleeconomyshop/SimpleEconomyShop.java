package com.rinsgt.simpleeconomyshop;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;

public class SimpleEconomyShop implements ModInitializer {
    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            Economy.load(server);
            Catalog.reset();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> Economy.save());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("shop").executes(ctx -> {
                ServerPlayer p = ctx.getSource().getPlayerOrException();
                p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new ShopMenu(id, inv, p), Component.literal("SHOP")));
                return 1;
            }));
            dispatcher.register(Commands.literal("sell").executes(ctx -> {
                ServerPlayer p = ctx.getSource().getPlayerOrException();
                p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new SellMenu(id, inv, p), Component.literal("SELL")));
                return 1;
            }));
        });
    }
}

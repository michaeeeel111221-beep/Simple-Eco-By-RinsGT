package com.rinsgt.simpleeconomyshop;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

/** Daftar semua item survival yang dijual di /shop. */
final class Catalog {
    record Entry(ItemStack stack, long sell, long buy) {}

    private static List<Entry> cache;

    static void reset() { cache = null; }

    static synchronized List<Entry> get(MinecraftServer server) {
        if (cache == null) cache = build(server);
        return cache;
    }

    private static List<Entry> build(MinecraftServer server) {
        List<Entry> out = new ArrayList<>();
        for (Item item : BuiltInRegistries.ITEM) {
            ItemStack st = new ItemStack(item);
            long sell = Prices.sell(st);
            if (sell <= 0) continue;
            out.add(new Entry(st, sell, Prices.buyFromSell(sell)));
        }
        var reg = server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        reg.listElements().forEach(h -> {
            int max = h.value().getMaxLevel();
            for (int lvl = 1; lvl <= max; lvl++) {
                final int l = lvl;
                ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
                EnchantmentHelper.updateEnchantments(book, m -> m.set(h, l));
                long sell = Prices.sell(book);
                if (sell > 0) out.add(new Entry(book, sell, Prices.buyFromSell(sell)));
            }
        });
        return out;
    }
}
